package com.example.tyredefectcameradetection;


import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import androidx.appcompat.app.AppCompatActivity;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

// This is the main class of the application that extends the AppCompatActivity class
public class MainActivity extends AppCompatActivity {

    // Constants
    private static final int REQUEST_IMAGE_SELECT = 2;

    // TextView to display the result of the image processing
    private TextView mResultTextView;

    //        DEPRECATED VARIABLES
        private static final int REQUEST_IMAGE_CAPTURE = 1;
    // URL for the server where the image will be sent for processing


    // This method is called when the activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the TextView in the layout and set it to the mResultTextView variable
        mResultTextView = findViewById(R.id.result_text_view);

        // Find the ImageButton in the layout and set a listener to capture an image
        ImageButton captureButton = findViewById(R.id.capture_button);

        captureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dispatchTakePictureIntent();
            }
        });
    }

    // This method is called when the user clicks the ImageButton to capture an image
    private void dispatchTakePictureIntent() {
//                COMMENTED CODE FOR DEPRECTAED CAMERA OPERATION
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
//        Intent selectPictureIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//        if (selectPictureIntent.resolveActivity(getPackageManager()) != null) {
//            startActivityForResult(selectPictureIntent, REQUEST_IMAGE_SELECT);
//        }
    }

    // This method is called after the user selects an image
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //        COMMENTED CODE FOR DEPRECTAED CAMERA OPERATION
                if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
                    Bitmap imageBitmap = (Bitmap) data.getExtras().get("data");
                    ImageView imageView = findViewById(R.id.image_view);
                    imageView.setImageBitmap(imageBitmap);
                    sendPhotoToServer(imageBitmap);
                }
//        if (requestCode == REQUEST_IMAGE_SELECT && resultCode == RESULT_OK) {
//            try {
//                Uri imageUri = data.getData();
//                Bitmap imageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
//
//                // Resize the image to a smaller size for better visualization
//                Bitmap resizedBitmap = imageBitmap.createScaledBitmap(imageBitmap, 250, 250, false);
//                ImageView imageView = findViewById(R.id.image_view);
//                imageView.setImageBitmap(resizedBitmap);
//                mResultTextView.setText("Processing Image...");
//
//                // Send the original image to the server for processing
//                sendPhotoToServer(imageBitmap);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
    }
    // This class represents an AsyncTask that sends a photo to a server and receives a response
    private class SendPhotoTask extends AsyncTask<Bitmap, Void, String> {

        @Override
        protected String doInBackground(Bitmap... bitmaps) {
            Bitmap bitmap = bitmaps[0];
            // Convert bitmap to byte array
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            byte[] byteArray = stream.toByteArray();

            // Create HTTP client
            OkHttpClient client = new OkHttpClient().newBuilder()
                    .connectTimeout(10, TimeUnit.SECONDS)
                    .readTimeout(10, TimeUnit.SECONDS)
                    .writeTimeout(10, TimeUnit.SECONDS).build();
            // Find the EditText in the layout and set its value to the SERVER_URL variable
//            EditText serverUrlEditText = findViewById(R.id.server_url_edit_text);
//            String SERVER_URL = serverUrlEditText.getText().toString();
            String SERVER_URL = "192.168.2.140";
            if (SERVER_URL.isEmpty()) {
                // String is empty
                return "Please enter server address";
            }
            try{
                // Build request
                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("image", "image.jpg", RequestBody.create(MediaType.parse("image/jpeg"), byteArray))
                        .build();
//            Log.i("url_check","http://"+SERVER_URL+":5000/");
                Request request = new Request.Builder()
                        .url("http://" + SERVER_URL + ":5000/")
                        .post(requestBody)
                        .build();


                // Send request
                try {
                    Response response = client.newCall(request).execute();

                    // Check response code
                    if (!response.isSuccessful()) {
                        throw new Exception("Server error");
                    }

                    // Read response
                    String responseBody = response.body().string();

                    // Update UI
                    return new JSONObject(responseBody).getString("text");

                } catch (Exception e) {
                    e.printStackTrace();
                    return "Error:"+ e.getMessage();
                }
            }catch (Exception e) {
                return "Error:Unable to connect to server";
            }
        }

        @Override
        protected void onPostExecute(String result) {

            mResultTextView.setText(result);
        }
    }

    // Call this method to send the photo to the server
    private void sendPhotoToServer(Bitmap bitmap) {
        // Execute the SendPhotoTask AsyncTask to send the photo
        new SendPhotoTask().execute(bitmap);
    }

}
